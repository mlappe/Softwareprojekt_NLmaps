#!/usr/bin/env bash
cd /home/ozan/Schreibtisch/progTest2/mert-work
/home/ozan/mosesdecoder/bin/extractor --sctype BLEU --scconfig case:true  --scfile run8.scores.dat --ffile run8.features.dat -r /home/ozan/Schreibtisch/progTest2/corps/tune.mrl -n run8.best100.out.gz
